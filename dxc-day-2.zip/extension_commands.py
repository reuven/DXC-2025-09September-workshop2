def say_with_stars(self, line):
    """Print to the user with *stars* before and after"""
    print(f'I am saying: **{line}**')

def say_with_dollars(self, line):
    """Print to the user with $$dollars$$ before and after"""
    print(f'I am saying: $${line}$$')
